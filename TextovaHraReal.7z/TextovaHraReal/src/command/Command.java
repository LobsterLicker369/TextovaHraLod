package command;

public interface Command {
    String execute();
    boolean exit();
}
